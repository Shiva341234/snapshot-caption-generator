
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const captionDiv = document.getElementById('caption');
const captureBtn = document.getElementById('capture-btn');
const themeToggle = document.getElementById('theme-toggle');
const snapshotContainer = document.getElementById('snapshot-container');
const snapshotImage = document.getElementById('snapshot-image');
const copyCaptionBtn = document.getElementById('copy-caption-btn');
const downloadBtn = document.getElementById('download-btn');
const toast = document.getElementById('toast');
const socialIcons = document.getElementById('social-icons');
const twitterShare = document.getElementById('share-twitter');
const facebookShare = document.getElementById('share-facebook');
const instagramShare = document.getElementById('share-instagram');
const snapchatShare = document.getElementById('share-snapchat');

let generatedCaption = "";
let capturedImageBlob = null;

// Access webcam
navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
        video.srcObject = stream;
    });

captureBtn.addEventListener('click', () => {
    captureSnapshot();
});

function captureSnapshot() {
    const context = canvas.getContext('2d');
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    canvas.toBlob(blob => {
        capturedImageBlob = blob;
        snapshotImage.src = URL.createObjectURL(blob);
        snapshotContainer.style.display = 'block';
        generateCaption();
    }, 'image/jpeg');
}

async function generateCaption() {
    captionDiv.innerText = "Generating caption... ⏳";
    socialIcons.style.display = "none";

    const formData = new FormData();
    formData.append('image', capturedImageBlob);

    const response = await fetch('http://localhost:5000/generate_caption', {
        method: 'POST',
        body: formData
    });

    const data = await response.json();
    generatedCaption = data.caption;
    captionDiv.innerText = generatedCaption;

    setupSharing();
}

copyCaptionBtn.addEventListener('click', () => {
    navigator.clipboard.writeText(generatedCaption);
    showToast();
});

downloadBtn.addEventListener('click', () => {
    const a = document.createElement('a');
    a.href = snapshotImage.src;
    a.download = 'captured_snapshot.jpg';
    a.click();
});

function setupSharing() {
    socialIcons.style.display = "flex";

    const captionEncoded = encodeURIComponent(generatedCaption);
    twitterShare.href = `https://twitter.com/intent/tweet?text=${captionEncoded}`;
    facebookShare.href = `https://www.facebook.com/sharer/sharer.php?u=https://yourwebsite.com&quote=${captionEncoded}`;
    instagramShare.href = snapshotImage.src;
    snapchatShare.href = snapshotImage.src;
}

function showToast() {
    toast.className = "show";
    setTimeout(() => { toast.className = toast.className.replace("show", ""); }, 3000);
}

themeToggle.addEventListener('click', () => {
    document.body.classList.toggle('dark');
});
