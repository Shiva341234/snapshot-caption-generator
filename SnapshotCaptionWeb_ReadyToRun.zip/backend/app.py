
from flask import Flask, request, jsonify
from flask_cors import CORS
from PIL import Image
import io
import random

app = Flask(__name__)
CORS(app)

# Dummy AI caption generator - replace with real ML model logic
def generate_caption_from_image(image_data):
    dummy_captions = [
        "A moment worth a thousand words 📸",
        "Caught in the act! 🎬",
        "When memories freeze in time 🧊",
        "Just vibing in the moment 😎",
        "Snap it. Cap it. Share it. ✨"
    ]
    return random.choice(dummy_captions)

@app.route('/generate_caption', methods=['POST'])
def generate_caption():
    if 'image' not in request.files:
        return jsonify({'error': 'No image uploaded'}), 400

    image_file = request.files['image']
    try:
        image = Image.open(image_file.stream)
        caption = generate_caption_from_image(image)
        return jsonify({'caption': caption})
    except Exception as e:
        return jsonify({'error': 'Image processing failed', 'details': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
